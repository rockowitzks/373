package software;

import java.util.*;

import reservables.Company;
import reservables.air.Airport;
import reservables.air.Route;
import reservables.cars.Car;
import reservables.hotels.Hotel;
import users.Account;

public class Website {
	private ArrayList<Company> companyList;
	private ArrayList<Airport> airportList;
	private ArrayList<Route> returnRouteList;
	private ArrayList<Route> departureRouteList;
	private ArrayList<Hotel> hotelList;
	private ArrayList<Car> carList;
	private Account currentAccount;

	public ArrayList<Company> getCompanyList() {
		return this.companyList;
	}

	public ArrayList<Airport> getAirportList() {
		return this.airportList;
	}

	public ArrayList<Route> getReturnRouteList() {
		return this.returnRouteList;
	}

	public ArrayList<Route> getDepartureRouteList() {
		return this.departureRouteList;
	}

	public ArrayList<Hotel> getHotelList() {
		return this.hotelList;
	}

	public ArrayList<Car> getCarList() {
		return this.carList;
	}

	public Account getCurrentAccount() {
		return this.currentAccount;
	}

	public void setCompanyList(ArrayList<Company> companyList) {
		this.companyList = companyList;
	}

	public void setAirportList(ArrayList<Airport> airportList) {
		this.airportList = airportList;
	}

	public void setReturnRouteList(ArrayList<Route> returnRouteList) {
		this.returnRouteList = returnRouteList;
	}

	public void setDepartureRouteList(ArrayList<Route> departureRouteList) {
		this.departureRouteList = departureRouteList;
	}

	public void setHotelList(ArrayList<Hotel> hotelList) {
		this.hotelList = hotelList;
	}

	public void setCarList(ArrayList<Car> carList) {
		this.carList = carList;
	}

	public void setCurrentAccount(Account currentAccount) {
		this.currentAccount = currentAccount;
	}

	public void createAccount( ) {
		// TODO should be implemented
	}

	public void logIn( ) {
		// TODO should be implemented
	}

	public void findReservation( ) {
		// TODO should be implemented
	}

	public void calculateRoutes(Airport destination, Airport departing) {
		// TODO should be implemented
	}

	public  Website() {
		// TODO should be implemented
	}
}
