
public class Website {
	private ArrayList<> companyList;
	private ArrayList<> airportList;
	private ArrayList<> returnRouteList;
	private ArrayList<> departureRouteList;
	private ArrayList<> hotelList;
	private ArrayList<> carList;
	private Account currentAccount;

	public ArrayList<> getCompanyList() {
		return this.companyList;
	}

	public ArrayList<> getAirportList() {
		return this.airportList;
	}

	public ArrayList<> getReturnRouteList() {
		return this.returnRouteList;
	}

	public ArrayList<> getDepartureRouteList() {
		return this.departureRouteList;
	}

	public ArrayList<> getHotelList() {
		return this.hotelList;
	}

	public ArrayList<> getCarList() {
		return this.carList;
	}

	public Account getCurrentAccount() {
		return this.currentAccount;
	}

	public void setCompanyList(ArrayList<> companyList) {
		this.companyList = companyList;
	}

	public void setAirportList(ArrayList<> airportList) {
		this.airportList = airportList;
	}

	public void setReturnRouteList(ArrayList<> returnRouteList) {
		this.returnRouteList = returnRouteList;
	}

	public void setDepartureRouteList(ArrayList<> departureRouteList) {
		this.departureRouteList = departureRouteList;
	}

	public void setHotelList(ArrayList<> hotelList) {
		this.hotelList = hotelList;
	}

	public void setCarList(ArrayList<> carList) {
		this.carList = carList;
	}

	public void setCurrentAccount(Account currentAccount) {
		this.currentAccount = currentAccount;
	}

	public void createAccount( ) {
		// TODO should be implemented
	}

	public void logIn( ) {
		// TODO should be implemented
	}

	public void findReservation( ) {
		// TODO should be implemented
	}

	public void calculateRoutes( Airport destination Airport departing ) {
		// TODO should be implemented
	}

	public  Website() {
		// TODO should be implemented
	}
}
