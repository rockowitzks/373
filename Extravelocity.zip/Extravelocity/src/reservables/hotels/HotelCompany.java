package reservables.hotels;

import java.util.*;

import reservables.*;

public class HotelCompany extends Company {
	public ArrayList<Hotel> hotels;

	public ArrayList<Hotel> getHotels() {
		return this.hotels;
	}

	public void setHotels(ArrayList<Hotel> hotels) {
		this.hotels = hotels;
	}

	public  HotelCompany() {
		// TODO should be implemented
	}

	public double calculatePrice( ) {
		return 0;
		// TODO should be implemented
	}
}
