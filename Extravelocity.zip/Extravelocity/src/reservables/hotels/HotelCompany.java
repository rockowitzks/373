package reservables.hotels;

public class HotelCompany extends Company {
	public ArrayList<> hotels;

	public ArrayList<> getHotels() {
		return this.hotels;
	}

	public void setHotels(ArrayList<> hotels) {
		this.hotels = hotels;
	}

	public  HotelCompany() {
		// TODO should be implemented
	}

	public double calculatePrice( ) {
		// TODO should be implemented
	}
}
