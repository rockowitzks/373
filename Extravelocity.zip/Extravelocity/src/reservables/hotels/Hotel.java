package reservables.hotels;

import java.util.*;

import users.*;

public class Hotel {
	private ArrayList<Room> rooms;
	private ArrayList<Account> guests;
	private int stars;
	private int numServices;

	public ArrayList<Room> getRooms() {
		return this.rooms;
	}

	public ArrayList<Account> getGuests() {
		return this.guests;
	}

	public int getStars() {
		return this.stars;
	}

	public int getNumServices() {
		return this.numServices;
	}

	public void setRooms(ArrayList<Room> rooms) {
		this.rooms = rooms;
	}

	public void setGuests(ArrayList<Account> guests) {
		this.guests = guests;
	}

	public void setStars(int stars) {
		this.stars = stars;
	}

	public void setNumServices(int numServices) {
		this.numServices = numServices;
	}

	public  Hotel() {
		// TODO should be implemented
	}
}
