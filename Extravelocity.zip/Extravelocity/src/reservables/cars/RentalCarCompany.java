package reservables.cars;

import java.util.*;

import reservables.*;

public class RentalCarCompany extends Company {
	public ArrayList<Location> locations;

	public ArrayList<Location> getLocations() {
		return this.locations;
	}

	public void setLocations(ArrayList<Location> locations) {
		this.locations = locations;
	}

	public  RentalCarCompany() {
		// TODO should be implemented
	}

	public double calculatePrice( ) {
		return 0;
		// TODO should be implemented
	}
}
