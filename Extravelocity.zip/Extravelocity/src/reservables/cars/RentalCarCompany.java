package reservables.cars;

public class RentalCarCompany extends Company {
	public ArrayList<> locations;

	public ArrayList<> getLocations() {
		return this.locations;
	}

	public void setLocations(ArrayList<> locations) {
		this.locations = locations;
	}

	public  RentalCarCompany() {
		// TODO should be implemented
	}

	public double calculatePrice( ) {
		// TODO should be implemented
	}
}
