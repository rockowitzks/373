package reservables;


public class Date {
	private int month;
	private int day;
	private int year;

	public int getMonth() {
		return this.month;
	}

	public int getDay() {
		return this.day;
	}

	public int getYear() {
		return this.year;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public  Date() {
		// TODO should be implemented
	}
}
