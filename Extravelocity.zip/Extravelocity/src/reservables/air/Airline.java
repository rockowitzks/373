package reservables.air;

import java.util.*;

import reservables.Company;

public class Airline extends Company

//public class Airline extends Company {
//	private ArrayList<Airport> airports;
//	
//	public ArrayList<Airport> getAirports() {
//		return this.airports;
//	}
//	
//	public void setAirports(ArrayList<Airport> airports) {
//		this.airports = airports;
//	}
//
//	public Airline() {
//		// TODO should be implemented
//	}
//
//	public double calculatePrice() {
//		return 0;
//		// TODO should be implemented
//	}
//}
