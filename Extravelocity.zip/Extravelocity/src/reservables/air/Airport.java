package reservables.air;

public class Airport {
	private ArrayList<> arrivalList;
	private ArrayList<> departureList;
	private ArrayList<> airlineList;
	private int group;

	public ArrayList<> getArrivalList() {
		return this.arrivalList;
	}

	public ArrayList<> getDepartureList() {
		return this.departureList;
	}

	public ArrayList<> getAirlineList() {
		return this.airlineList;
	}

	public int getGroup() {
		return this.group;
	}

	public void setArrivalList(ArrayList<> arrivalList) {
		this.arrivalList = arrivalList;
	}

	public void setDepartureList(ArrayList<> departureList) {
		this.departureList = departureList;
	}

	public void setAirlineList(ArrayList<> airlineList) {
		this.airlineList = airlineList;
	}

	public void setGroup(int group) {
		this.group = group;
	}

	public void addArrival( ) {
		// TODO should be implemented
	}

	public void addDeparture( ) {
		// TODO should be implemented
	}

	public void addAirline( ) {
		// TODO should be implemented
	}

	public  Airport() {
		// TODO should be implemented
	}
}
