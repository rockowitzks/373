package reservables.air;

import java.util.*;

public class Airport {
	private ArrayList<Flight> arrivalList;
	private ArrayList<Flight> departureList;
	private ArrayList<Airline> airlineList;
	private int group;

	public ArrayList<Flight> getArrivalList() {
		return this.arrivalList;
	}

	public ArrayList<Flight> getDepartureList() {
		return this.departureList;
	}

	public ArrayList<Airline> getAirlineList() {
		return this.airlineList;
	}

	public int getGroup() {
		return this.group;
	}

	public void setArrivalList(ArrayList<Flight> arrivalList) {
		this.arrivalList = arrivalList;
	}

	public void setDepartureList(ArrayList<Flight> departureList) {
		this.departureList = departureList;
	}

	public void setAirlineList(ArrayList<Airline> airlineList) {
		this.airlineList = airlineList;
	}

	public void setGroup(int group) {
		this.group = group;
	}

	public void addArrival( ) {
		// TODO should be implemented
	}

	public void addDeparture( ) {
		// TODO should be implemented
	}

	public void addAirline( ) {
		// TODO should be implemented
	}

	public  Airport() {
		// TODO should be implemented
	}
}
