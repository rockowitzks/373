package reservables.air;
public class Layover {
	private Airport airport;
	private int time;

	public Airport getAirport() {
		return this.airport;
	}

	public int getTime() {
		return this.time;
	}

	public void setAirport(Airport airport) {
		this.airport = airport;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public Layover() {
		// TODO should be implemented
	}
}
