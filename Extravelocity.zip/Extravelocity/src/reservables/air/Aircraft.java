package reservables.air;

public class Aircraft {
	private String model;

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public  Aircraft() {
		// TODO should be implemented
	}
}
